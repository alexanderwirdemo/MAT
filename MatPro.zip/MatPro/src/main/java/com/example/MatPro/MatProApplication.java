package com.example.MatPro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MatProApplication {

	public static void main(String[] args) {
		SpringApplication.run(MatProApplication.class, args);






	}



}
