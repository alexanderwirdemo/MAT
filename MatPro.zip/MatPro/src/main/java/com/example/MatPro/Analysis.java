package com.example.MatPro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.Collections;
import java.util.List;

@Controller
public class Analysis {

    @Autowired
    private ProdRepository productrepo;

    @Autowired
    private OrderHasProductRepository orderhasprodrepo;

    @Autowired
    private CustomerOrderRepository customerorderrepo;

    @Autowired
    private ProcurementRepository procurementrepo;

    @Autowired
    private procurementhasproductRepository procurementproductrepo;

    public Analysis() {
    }

    public Analysis(ProdRepository productrepo) {
        this.productrepo = productrepo;
    }

    public Analysis(OrderHasProductRepository orderhasprodrepo) {
        this.orderhasprodrepo = orderhasprodrepo;
    }

    public Analysis(CustomerOrderRepository customerorderrepo) {
        this.customerorderrepo = customerorderrepo;
    }

    public Analysis(ProcurementRepository procurementrepo) {
        this.procurementrepo = procurementrepo;
    }

    public Analysis(procurementhasproductRepository procurementproductrepo) {
        this.procurementproductrepo = procurementproductrepo;
    }

    public ProdRepository getProductrepo() {
        return productrepo;
    }

    public OrderHasProductRepository getOrderhasprodrepo() {
        return orderhasprodrepo;
    }

    public CustomerOrderRepository getCustomerorderrepo() {
        return customerorderrepo;
    }

    public ProcurementRepository getProcurementrepo() {
        return procurementrepo;
    }

    public procurementhasproductRepository getProcurementproductrepo() {
        return procurementproductrepo;
    }


    @PostMapping("/astock")
    public String astock(Model model) {
        List<Product> allProducts = (List<Product>) productrepo.findAll();
        model.addAttribute( "allProducts", allProducts );
        int purchasePrice = 0;
        for (int i=0;i<allProducts.size();i++)
        {
            purchasePrice += ((allProducts.get(i).getPurchaseprice())* (allProducts.get( i ).getStockquantity()));
        }
        int price = 0;
        for (int i=0;i<allProducts.size();i++)
        {
            price += ((allProducts.get(i).getPrice())* (allProducts.get( i ).getStockquantity()));
        }

        if (purchasePrice<=price){
            int astock = purchasePrice;
            return "astock";
        }
        else {
            int astock = price;
            return "astock";
        }
    }

    @PostMapping("/aorders")
    public String aorders(Model model) {
        List<Orderhasproduct> allOrders = (List<Orderhasproduct>) orderhasprodrepo.findAll();
        model.addAttribute( "allOrders", allOrders );
        List<Product> allProducts = (List<Product>) productrepo.findAll();
        model.addAttribute( "allProducts", allProducts );
        int priceAdjustment = 0;
        for (int i=0;i<allOrders.size();i++)
        {
            priceAdjustment += ((allOrders.get(i).getPriceadjustment())* (allOrders.get(i).getQuantity()));
        }
        int price = 0;
        for (int i=0;i<allProducts.size();i++)
        {
            price += ((allProducts.get(i).getPrice())* (allOrders.get( i ).getQuantity())-priceAdjustment);
        }
        int aorders=price;
        return "aorders";
        }

    @PostMapping("/aprocurements")
    public String aprocurements(Model model) {
        List<Procurementhasproduct> allProcurements = (List<Procurementhasproduct>) procurementproductrepo.findAll();
        model.addAttribute( "allProcurements", allProcurements );
        List<Product> allProducts = (List<Product>) productrepo.findAll();
        model.addAttribute( "allProducts", allProducts );
        int priceAdjustment = 0;
        for (int i=0;i<allProcurements.size();i++)
        {
            priceAdjustment += ((allProcurements.get(i).getPriceadjustment())* (allProcurements.get( i ).getQuantity()));
        }
        int value = 0;
        for (int i=0;i<allProducts.size();i++)
        {
            value += ((allProducts.get(i).getPrice())* (allProcurements.get( i ).getQuantity())-priceAdjustment);
        }
        int aprocurements=value;
        return "aprocurements";
    }


}
