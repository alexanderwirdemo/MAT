package com.example.MatPro;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Orderhasproduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer orderproduct;
    Integer orderid;
    Integer productno;
    Integer quantity;
    Float priceadjustment;
    Float vat;
    Boolean orderhasbeensent;

    public Orderhasproduct() { }

    public Orderhasproduct(Integer orderproduct, Integer orderid, Integer productno, Integer quantity, Float priceadjustment, Float vat, Boolean orderhasbeensent) {
        this.orderproduct = orderproduct;
        this.orderid = orderid;
        this.productno = productno;
        this.quantity = quantity;
        this.priceadjustment = priceadjustment;
        this.vat = vat;
        this.orderhasbeensent = orderhasbeensent;
    }

    public Boolean getOrderhasbeensent() {
        return orderhasbeensent;
    }

    public void setOrderhasbeensent(Boolean orderhasbeensent) {
        this.orderhasbeensent = orderhasbeensent;
    }

    public Integer getOrderproduct() {
        return orderproduct;
    }

    public void setOrderproduct(Integer orderproduct) {
        this.orderproduct = orderproduct;
    }

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public int getProductno() {
        return productno;
    }

    public void setProductno(int productno) {
        this.productno = productno;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        quantity = quantity;
    }

    public float getPriceadjustment() {
        return priceadjustment;
    }

    public void setPriceadjustment(float priceadjustment) {
        this.priceadjustment = priceadjustment;
    }

    public float getVat() {
        return vat;
    }

    public void setVat(float vat) {
        this.vat = vat;
    }
}
