package com.example.MatPro;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDate;
import java.util.Date;

@Entity
public class Customerorder {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer orderid;
    int customerid;
    LocalDate date;
    float freight;
    Boolean orderhasbeensent;


    public Customerorder(Integer orderid, int customerid, LocalDate date, float freight, Boolean orderhasbeensent) {
        this.orderid = orderid;
        this.customerid = customerid;
        this.date = date;
        this.freight = freight;
        this.orderhasbeensent = orderhasbeensent;
    }

    public Boolean getOrderhasbeensent() {
        return orderhasbeensent;
    }

    public void setOrderhasbeensent(Boolean orderhasbeensent) {
        this.orderhasbeensent = orderhasbeensent;
    }

    public Customerorder() {
    }

    public Integer getOrderid() {
        return orderid;
    }

    public void setOrderid(Integer orderid) {
        this.orderid = orderid;
    }

    public int getCustomerid() {
        return customerid;
    }

    public void setCustomerid(int customerid) {
        this.customerid = customerid;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public float getFreight() {
        return freight;
    }

    public void setFreight(float freight) {
        this.freight = freight;
    }
}
