package com.example.MatPro;

import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;


@Controller
public class ProductController {

    @Autowired
    private ProdRepository productrepo;

    @Autowired
    private OrderHasProductRepository orderhasprodrepo;

    @Autowired
    private CustomerOrderRepository customerorderrepo;

    @Autowired
    private AddressRepository addressrepo;

    @Autowired
    private CustomertelephoneRepository telephonerepo;

    @Autowired
    private PaymentinfoRepository paymentrepo;

    @Autowired
    private ProcurementRepository procurementrepo;

    @Autowired
    private procurementhasproductRepository procurementproductrepo;

    @Autowired
    private SuppliertelephoneRepository suppliertelephonerepo;

    @Autowired
    private SupplierRepository supplierrepo;

    @Autowired
    private CustomerRepository customerrepo;

    @Autowired
    private LoginRepository loginrepo;


    @GetMapping("/")
    public String test() {
        return "login";
    }

    @GetMapping("/login")
    public String getLogin(HttpSession session) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "HandleStock";
        } else {
            return "login";
        }
    }

    @PostMapping("/login")
    public String postLogin(Model model, HttpSession session, @RequestParam String username, @RequestParam String password) {

        List<Login> allInlogs = (List<Login>)loginrepo.findAll();

        for (int i=0;i<allInlogs.size();i++)
        {
            if (username.equals(allInlogs.get(i).getUsername())&&(password.equals(allInlogs.get(i).getPassword())))
            {
                session.setAttribute("username",username);
            }
        }

        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            List<Product> allProducts = (List<Product>)productrepo.findAll();
            model.addAttribute("allProducts", allProducts);
            List<Customerorder> customer = (List<Customerorder>)customerorderrepo.findAll();

            for (int i=0;i<customer.size();i++)
            {
                if (customer.get(i).getOrderhasbeensent())
                {
                    customer.remove(customer.get(i));
                    i--;
                }
            }
            model.addAttribute("customer", customer);
            List<Orderhasproduct> orderprod = (List<Orderhasproduct>)orderhasprodrepo.findAll();
            for (int i=0;i<orderprod.size();i++)
            {
                if (orderprod.get(i).getOrderhasbeensent())
                {
                    orderprod.remove(orderprod.get(i));
                    i--;
                }
            }
            model.addAttribute("orderprod", orderprod);

            List<Procurement> procurement = (List<Procurement>)procurementrepo.findAll();
            for (int i=0;i<procurement.size();i++)
            {
                if (procurement.get(i).getHasbeenrecived())
                {
                    procurement.remove(procurement.get(i));
                    i--;
                }
            }
            model.addAttribute("procurement", procurement);
            List<Procurementhasproduct> procurementhasproduct = (List<Procurementhasproduct>)procurementproductrepo.findAll();
            for (int i=0;i<procurementhasproduct.size();i++)
            {
                if (procurementhasproduct.get(i).getProducthasbeenrecived())
                {
                    procurementhasproduct.remove(procurementhasproduct.get(i));
                    i--;
                }
            }
            model.addAttribute("procurementhasproduct", procurementhasproduct);
            return "/HandleStock";
        } else {
            return "login";
        }
    }

    @GetMapping("/logout")
    public String getLogout(HttpSession session) {
        session.invalidate();
        return "login";
    }

    @GetMapping("/products")
    public String productStartPage(HttpSession session){
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "products";
        } else {
            return "login";
        }
    }
    @GetMapping("/products/{id}")
    public String product(@PathVariable int id, Model model,HttpSession session){

        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            model.addAttribute("productid",id);
            return "product";
        } else {
            return "login";
        }
    }

    //CUSTOMER ORDER PAGE

    @GetMapping("/warehouse/order/{id}")
    public String getorder (Model model, @PathVariable Integer id,HttpSession session) {

        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            Customerorder order = customerorderrepo.findById(id).get();
            model.addAttribute("customer", order);

            List<Orderhasproduct> orderprod = orderhasprodrepo.findAllByOrderid(id);
            for (int i=0;i<orderprod.size();i++)
            {
                if (orderprod.get(i).getOrderhasbeensent())
                {
                    orderprod.remove(orderprod.get(i));
                    i--;
                }
            }
            model.addAttribute("orderprod", orderprod);

            List<Product> products = new ArrayList<>();
            for (Integer i=0;i<orderprod.size();i++) {
                products.add(productrepo.findById(orderprod.get(i).getProductno()).get());
            }
            List<Product> newprodlist = products.stream().distinct().collect(Collectors.toList());
            model.addAttribute("allProducts",newprodlist);
            List<Product> assortment = (List<Product>)productrepo.findAll();
model.addAttribute ("assortment", assortment );
            return "HandleOrders";
        } else {
            return "login";
        }
    }



    /**
     * A post-mapping method to pack customer orders from warehouse
     * @param model
     * @param id
     * @return
     */

    @PostMapping("/warehouse/order/{id}")
    public String updateQuantityorder (Model model, @PathVariable Integer id,HttpSession session){
        Customerorder order = customerorderrepo.findById(id).get();

        List<Orderhasproduct> orderprod = orderhasprodrepo.findAllByOrderid(id);

        for (int i=0;i<orderprod.size();i++)
        {
            if(orderprod.get(i).getOrderhasbeensent())
            {
                orderprod.remove(orderprod.get(i));
                i--;
            }
        }

        List<Product> products = new ArrayList<>();
        boolean orderIsComplete = true;
        for (Integer i=0;i<orderprod.size();i++) {
            Product product = productrepo.findById(orderprod.get(i).getProductno()).get();

            if(product.getStockquantity()-orderprod.get(i).getQuantity()>=0){
                if(product.getStockquantity()-orderprod.get(i).getQuantity()<product.getSafetystock()) {
                    System.out.println("WARNING, STOCK LEVELS LOW!!!");

                    List<Procurementhasproduct> allprocofprod = (List)procurementproductrepo.findAllByProductno(product.getProductno());

                    for (int j=0;j<allprocofprod.size();j++)
                    {
                        if(allprocofprod.get(j).getProducthasbeenrecived())
                        {
                            allprocofprod.remove(allprocofprod.get(j));
                            j--;
                        }
                    }

                    boolean procurementexists=false;
                    int total=0;
                    for (int j=0;j<allprocofprod.size();j++)
                    {
                        total+=allprocofprod.get(j).getQuantity();
                    }

                    if (total>product.getSafetyorderquantity())
                    {
                        procurementexists=false;
                    }
                    else
                    {
                        LocalDate date = LocalDate.parse ("2019-09-20");
                        //Date dates = new SimpleDateFormat("yyyy-MM-dd").parse(date);
                        Procurement safetyprocurement = new Procurement(null,product.getSupplierid(),date,120,false);

                        Procurement newprocurement = procurementrepo.save(safetyprocurement);

                        Procurementhasproduct safetyprocurementorder = new Procurementhasproduct(null,newprocurement.getProducrementid(),product.getProductno(),product.getSafetyorderquantity()-total,0,12,false);

                        procurementproductrepo.save(safetyprocurementorder);
                    }
                }
                Product updatedProduct = new Product(product.getProductno(),product.getName(),product.getCategory(),product.getPrice(),product.getPurchaseprice(),product.getStockquantity()-orderprod.get(i).getQuantity(),product.getSafetystock(),product.getSafetyorderquantity (),product.getSupplierid());
                productrepo.save(updatedProduct);
                products.add(productrepo.findById(orderprod.get(i).getProductno()).get());

                Orderhasproduct uppdatedorderprod = new Orderhasproduct(orderprod.get(i).getOrderproduct(),orderprod.get(i).getOrderid(),orderprod.get(i).getProductno(),orderprod.get(i).getQuantity(),orderprod.get(i).getPriceadjustment(),orderprod.get(i).getVat(),true);
                orderhasprodrepo.save(uppdatedorderprod);
            }
            else{
                orderIsComplete = false;
            }
        }
        if(orderIsComplete) {

            Customerorder uppdatedorder = new Customerorder(order.getOrderid(),order.getCustomerid(),order.getDate(),order.getFreight(),true);
            customerorderrepo.save(uppdatedorder);
        }


        List<Product> allProducts = (List<Product>)productrepo.findAll();
        model.addAttribute("allProducts", allProducts);
        List<Customerorder> customer = (List<Customerorder>)customerorderrepo.findAll();
        for (int i=0;i<customer.size();i++)
        {
            if (customer.get(i).getOrderhasbeensent())
            {
                customer.remove(customer.get(i));
                i--;
            }
        }
        model.addAttribute("customer", customer);
        List<Orderhasproduct> orderprodd = (List<Orderhasproduct>)orderhasprodrepo.findAll();
        for (int i=0;i<orderprodd.size();i++)
        {
            if (orderprodd.get(i).getOrderhasbeensent())
            {
                orderprodd.remove(orderprodd.get(i));
                i--;
            }
        }
        model.addAttribute("orderprod", orderprodd);

        List<Procurement> procurementt = (List<Procurement>)procurementrepo.findAll();
        for (int i=0;i<procurementt.size();i++)
        {
            if (procurementt.get(i).getHasbeenrecived())
            {
                procurementt.remove(procurementt.get(i));
                i--;
            }
        }
        model.addAttribute("procurement", procurementt);
        List<Procurementhasproduct> procurementhasproductt = (List<Procurementhasproduct>)procurementproductrepo.findAll();
        for (int i=0;i<procurementhasproductt.size();i++)
        {
            if (procurementhasproductt.get(i).getProducthasbeenrecived())
            {
                procurementhasproductt.remove(procurementhasproductt.get(i));
                i--;
            }
        }
        model.addAttribute("procurementhasproduct", procurementhasproductt);

        return "HandleStock";
        }


    // @PutMapping("/warehouse/{id}")
    @GetMapping("/warehouse")
    public String post (Model model,HttpSession session) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {

            List<Product> allProducts = (List<Product>)productrepo.findAll();
            model.addAttribute("allProducts", allProducts);
            List<Customerorder> customer = (List<Customerorder>)customerorderrepo.findAll();
            for (int i=0;i<customer.size();i++)
            {
                if (customer.get(i).getOrderhasbeensent())
                {
                    customer.remove(customer.get(i));
                    i--;
                }
            }
            model.addAttribute("customer", customer);
            List<Orderhasproduct> orderprod = (List<Orderhasproduct>)orderhasprodrepo.findAll();
            for (int i=0;i<orderprod.size();i++)
            {
                if (orderprod.get(i).getOrderhasbeensent())
                {
                    orderprod.remove(orderprod.get(i));
                    i--;
                }
            }
            model.addAttribute("orderprod", orderprod);

            List<Procurement> procurement = (List<Procurement>)procurementrepo.findAll();
            for (int i=0;i<procurement.size();i++)
            {
                if (procurement.get(i).getHasbeenrecived())
                {
                    procurement.remove(procurement.get(i));
                    i--;
                }
            }
            model.addAttribute("procurement", procurement);
            List<Procurementhasproduct> procurementhasproduct = (List<Procurementhasproduct>)procurementproductrepo.findAll();
            for (int i=0;i<procurementhasproduct.size();i++)
            {
                if (procurementhasproduct.get(i).getProducthasbeenrecived())
                {
                    procurementhasproduct.remove(procurementhasproduct.get(i));
                    i--;
                }
            }
            model.addAttribute("procurementhasproduct", procurementhasproduct);

            return "HandleStock";
        } else {
            return "login";
        }

    }

    /**
     * A post-mapping method to enter all waiting procurements, stock at hand and all waiting customer orders.
     * @param model
     * @param searchBar
     * @return
     */

    @PostMapping("/warehouse")
    public String post (Model model, @RequestParam String searchBar,HttpSession session) {
        List<Product> allProducts = productrepo.findAllByName(searchBar);


//        for (int i=0;i<customer.size();i++)
//        {
//            if (customer.get(i).getOrderhasbeensent())
//            {
//                customer.remove(customer.get(i));
//                i--;
//            }
//        }
//        model.addAttribute("customer", customer);
//        List<Orderhasproduct> orderprod = (List<Orderhasproduct>)orderhasprodrepo.findAll();
//        for (int i=0;i<orderprod.size();i++)
//        {
//            if (orderprod.get(i).getOrderhasbeensent())
//            {
//                orderprod.remove(orderprod.get(i));
//                i--;
//            }
//        }
//

        //Customerorder customer;
        List<Customerorder> customerOrderList = new ArrayList<>();
        List<Orderhasproduct> orderhasprod = new ArrayList<>();
        List<Orderhasproduct> orderhasrightproduct = new ArrayList<>();

        List<Procurement>procurlist = new ArrayList<>();
        List<Procurementhasproduct> procurhasorder = new ArrayList<>();
        List<Procurementhasproduct> prohasrightproduct = new ArrayList<>();

        for (int i=0;i<allProducts.size();i++) {
            orderhasprod = orderhasprodrepo.findAllByProductno(allProducts.get(i).getProductno());
            for (int j=0;j<orderhasprod.size();j++) {
                orderhasrightproduct.add(orderhasprod.get(j));
            }
        }

        for (int i=0;i<orderhasrightproduct.size();i++)
        {
            if (orderhasrightproduct.get(i).getOrderhasbeensent())
            {
                orderhasrightproduct.remove(orderhasrightproduct.get(i));
                i--;
            }
        }

        for (int i=0;i<orderhasrightproduct.size();i++) {
            customerOrderList.add(customerorderrepo.findById(orderhasrightproduct.get(i).getOrderid()).get());
        }

        for (int i=0;i<customerOrderList.size();i++)
        {
            if (customerOrderList.get(i).getOrderhasbeensent())
            {
                customerOrderList.remove(customerOrderList.get(i));
                i--;
            }
        }

        List<Customerorder> newlist = customerOrderList.stream().distinct().collect(Collectors.toList());

        for (int i=0;i<newlist.size();i++)
        {
            if (newlist.get(i).getOrderhasbeensent())
            {
                newlist.remove(newlist.get(i));
                i--;
            }
        }

        for (int i=0;i<allProducts.size();i++) {
            procurhasorder = procurementproductrepo.findAllByProductno(allProducts.get(i).getProductno());
            for (int j=0;j<procurhasorder.size();j++) {
                prohasrightproduct.add(procurhasorder.get(j));
            }
        }

        for (int i=0;i<prohasrightproduct.size();i++) {
            procurlist.add(procurementrepo.findById(prohasrightproduct.get(i).getProcurementid()).get());
        }
        List<Procurement> newprolist = procurlist.stream().distinct().collect(Collectors.toList());
        for (int i=0;i<newprolist.size();i++)
        {
            if (newprolist.get(i).getHasbeenrecived())
            {
                newprolist.remove(newprolist.get(i));
                i--;
            }
        }
        model.addAttribute("procurement", newprolist);

        for (int i=0;i<prohasrightproduct.size();i++)
        {
            if (prohasrightproduct.get(i).getProducthasbeenrecived())
            {
                prohasrightproduct.remove(prohasrightproduct.get(i));
                i--;
            }
        }
        model.addAttribute("procurementhasproduct", prohasrightproduct);
        model.addAttribute("orderprod", orderhasrightproduct);
        model.addAttribute("allProducts", allProducts);
        model.addAttribute("customer", newlist);
        return "HandleStock";
    }

    @GetMapping("/createproduct")
    public String insertprod (Model model, HttpSession session) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            List<Supplier> allsupplierss = (List<Supplier>)supplierrepo.findAll();
            model.addAttribute("allsuppliers",allsupplierss);
            return "CreateProduct";
        } else {
            return "login";
        }
    }

    @PostMapping("/createproduct")
    public String insertprod (Model model, @RequestParam String name, String category, Float price, Float purchaseprice, Integer stockquantity, Integer safetystock, Integer safetyorderquantity, Integer supplierid, HttpSession session) {
        List<Product> allproducts = (List<Product>)productrepo.findAll();

        List<Supplier> allsuppliers = (List<Supplier>)supplierrepo.findAll();
        Boolean productisok=false;

        for (int i=0;i<allsuppliers.size();i++)
        {
            if (allsuppliers.get(i).getSupplierid().equals(supplierid))
            {
                productisok=true;
            }
        }

        if (productisok) {
            Product prod = new Product(null,name,category,price,purchaseprice,stockquantity,safetystock,safetyorderquantity,supplierid);
            productrepo.save(prod);
            model.addAttribute("product",prod);
            List<Supplier> allsupplierss = (List<Supplier>)supplierrepo.findAll();
            model.addAttribute("allsuppliers",allsupplierss);
            return "CreateProduct";
        } else {
            List<Supplier> allsupplierss = (List<Supplier>)supplierrepo.findAll();
            model.addAttribute("allsuppliers",allsupplierss);
            return "CreateProduct";
        }
    }

    //CUSTOMER AND CUSTOMER ORDERS METHODS
    @GetMapping ("/createcustomer")
    public String insertcust (HttpSession session) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "/createcustomer";
        } else {
            return "login";
        }
    }

    @PostMapping ("/createcustomer")
    public String insertcust (Model model, @RequestParam String name, String address, String zipcode,String country, String customeraddress, String customerzipcode,String customercountry, String telephonenumber, String customertype,HttpSession session ) {

        Address addres = new Address(null, address, zipcode, country);
        Address a = addressrepo.save(addres);
        Address billingaddres = new Address(null, customeraddress, customerzipcode, customercountry);
        Address b=addressrepo.save(billingaddres);

        Customertelephone custtele = new Customertelephone(null,1, telephonenumber);
        Customertelephone tele = telephonerepo.save(custtele);

        Customer customer = new Customer(null, 1, name, a.addressid, b.addressid, tele.telephoneid);
        customerrepo.save(customer);

        model.addAttribute("customer",customer);

        return "/createcustomer";
    }

    @GetMapping ("/createorder")
    public String insertord (HttpSession session, Model model) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            List<Customer> allcustomers = (List<Customer>)customerrepo.findAll();
            model.addAttribute("allcustomers",allcustomers);
            return "/createorder";
        } else {
            return "login";
        }
    }

    /**
     * A Post-mapping method that creates a new customer order.
     * @param model
     * @param customerid
     * @param date
     * @param freight
     * @return
     * @throws Exception
     */
    @PostMapping ("/createorder")
    public String insertord (Model model,@RequestParam Integer customerid, String date, Float freight,HttpSession session) throws Exception {
        LocalDate dates;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern ("yyyy-MM-dd");
        if(date!="")
        {
            dates = LocalDate.parse (date, formatter);
        }

        //För att hantera om datum inte anges.
      else
        {
            dates = LocalDate.parse ("2019-12-31", formatter);
        }

        List<Customer> allcustomers = (List<Customer>)customerrepo.findAll();
        Boolean orderisok=false;

        for (int i=0;i<allcustomers.size();i++)
        {
            if (allcustomers.get(i).getCustomerid().equals(customerid))
            {
                orderisok=true;
            }
        }

        if (orderisok) {
            Customerorder custorder = new Customerorder(null, customerid, dates, freight,false);
            Customerorder newcustomerorder = customerorderrepo.save(custorder);
            int customerOrderId = newcustomerorder.getOrderid ();
            model.addAttribute("custorder",custorder);


            List<Customer> allcustomerss = (List<Customer>)customerrepo.findAll();
            model.addAttribute("allcustomers",allcustomerss);
            return "redirect:/warehouse/order/"+customerOrderId;
        } else {
            List<Customer> allcustomerss = (List<Customer>)customerrepo.findAll();
            model.addAttribute("allcustomers",allcustomerss);
            return "/createorder";
        }
    }

    @GetMapping ("/addproductstoorder")
    public String insertproduct (HttpSession session) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "/addproductstoorder";
        } else {
            return "login";
        }
    }

    /**
     * A Post-mapping method that adds products to a customer order previously created.
     * @param model
     * @param orderid
     * @param productno
     * @param quantity
     * @param priceadjustment
     * @param vat
     * @return
     */
    @PostMapping ("/addproductstoorder")
    public String insertproduct (Model model, @RequestParam Integer orderid, Integer productno, Integer quantity, Float priceadjustment, Float vat, HttpSession session) {

        List<Customerorder> allorders = (List<Customerorder>)customerorderrepo.findAll();
        Boolean firstinsertisok=false;

        for (int i=0;i<allorders.size();i++)
        {
            if (allorders.get(i).getOrderid().equals(orderid))
            {
                firstinsertisok=true;
            }
        }

        List<Product> allproducts = (List<Product>)productrepo.findAll();
        Boolean insertisok=false;

        for (int i=0;i<allproducts.size();i++)
        {
            if (allproducts.get(i).getProductno().equals(productno) && firstinsertisok)
            {
                insertisok=true;
            }
        }

        if (insertisok) {
            Orderhasproduct addorder = new Orderhasproduct(null, orderid, productno, quantity, priceadjustment, vat,false);
            orderhasprodrepo.save(addorder);

            model.addAttribute("addproduct",addorder);
            return "/addproductstoorder";
        } else {
            return "/addproductstoorder";
        }
    }


    @PostMapping ("/addproductstoorder/{id}")
    public String insertproductid (Model model, @PathVariable Integer id, @RequestParam Integer productno, Integer quantity, Float priceadjustment, Float vat, HttpSession session) {

        List<Product> allproducts = (List<Product>)productrepo.findAll();
        Boolean insertisok=false;

        for (int i=0;i<allproducts.size();i++)
        {
            if (allproducts.get(i).getProductno().equals(productno))
            {
                insertisok=true;
            }
        }

        if (insertisok) {
            Orderhasproduct addorder = new Orderhasproduct(null, id, productno, quantity, priceadjustment, vat,false);
            orderhasprodrepo.save(addorder);

            Customerorder order = customerorderrepo.findById(id).get();
            model.addAttribute("customer", order);

            List<Orderhasproduct> orderprod = orderhasprodrepo.findAllByOrderid(id);
            List<Orderhasproduct> neworderprod = orderprod.stream().distinct().collect(Collectors.toList());

            for (int i=0;i<neworderprod.size();i++)
            {
                if (neworderprod.get(i).getOrderhasbeensent())
                {
                    neworderprod.remove(neworderprod.get(i));
                    i--;
                }
            }
            model.addAttribute("orderprod", neworderprod);

            List<Product> products = new ArrayList<>();
            for (Integer i=0;i<orderprod.size();i++) {
                products.add(productrepo.findById(orderprod.get(i).getProductno()).get());
            }
            List<Product> newprodlist = products.stream().distinct().collect(Collectors.toList());
            model.addAttribute("allProducts",newprodlist);
            List<Product> assortment = (List<Product>)productrepo.findAll();
            model.addAttribute ("assortment", assortment );
            return "HandleOrders";
        } else {
            Customerorder order = customerorderrepo.findById(id).get();
            model.addAttribute("customer", order);

            List<Orderhasproduct> orderprod = orderhasprodrepo.findAllByOrderid(id);
            List<Orderhasproduct> neworderprod = orderprod.stream().distinct().collect(Collectors.toList());
            model.addAttribute("orderprod", neworderprod);

            List<Product> products = new ArrayList<>();
            for (Integer i=0;i<orderprod.size();i++) {
                products.add(productrepo.findById(orderprod.get(i).getProductno()).get());
            }
            List<Product> newprodlist = products.stream().distinct().collect(Collectors.toList());
            model.addAttribute("allProducts",newprodlist);
            List<Product> assortment = (List<Product>)productrepo.findAll();
            model.addAttribute ("assortment", assortment );
            return "HandleOrders";
        }
    }

    //PROCUREMENT AND SUPPLIER LOGIC

    @GetMapping ("/createsupplier")
    public String insertsup (HttpSession session) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "/createsupplier";
        } else {
            return "login";
        }
    }

    @PostMapping ("/createsupplier")
    public String insertsup (Model model, @RequestParam String name, String address, String zipcode,String country, String supplierraddress, String supplierzipcode,String suppliercountry, String telephonenumber, String customertype, HttpSession session ) {

        Address addres = new Address(null, address, zipcode, country);
        Address a = addressrepo.save(addres);
        Address billingaddres = new Address(null, supplierraddress, supplierzipcode, suppliercountry);
        Address b=addressrepo.save(billingaddres);

        Suppliertelephone suptel = new Suppliertelephone(null,1, telephonenumber);
        Suppliertelephone tele = suppliertelephonerepo.save(suptel);

        Supplier supplier = new Supplier(null, 1, name, a.addressid, b.addressid, tele.telephoneid);
        supplierrepo.save(supplier);
        model.addAttribute("supplier",supplier);

        return "/createsupplier";
    }


    @GetMapping ("/createprocurement")
    public String insertpro (HttpSession session, Model model) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            List<Supplier> allsuppliers = (List<Supplier>)supplierrepo.findAll();
            model.addAttribute("allsuppliers",allsuppliers);
            return "/createprocurement";
        } else {
            return "login";
        }
    }

    /**
     * A Post-mapping method that creates a procurement order, whoch will later be filled with procurement items
     * @param model
     * @param supplierid
     * @param date
     * @param freight
     * @return
     * @throws Exception
     */
    @PostMapping ("/createprocurement")
    public String insertpro (Model model,@RequestParam Integer supplierid, String date, Float freight, HttpSession session) throws Exception {

        LocalDate dates;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern ("yyyy-MM-dd");
        if(date!="")
        {
            dates = LocalDate.parse (date, formatter);
        }

        //För att hantera om datum inte anges.
        else
        {
            dates = LocalDate.parse ("2019-12-31", formatter);
        }

        List<Supplier> allsuppliers = (List<Supplier>)supplierrepo.findAll();
        Boolean procurementisok=false;

        for (int i=0;i<allsuppliers.size();i++)
        {
            if (allsuppliers.get(i).getSupplierid().equals(supplierid))
            {
                procurementisok=true;
            }
        }
        if (procurementisok) {
            Procurement procurement = new Procurement(null, supplierid, dates, freight,false);
           Procurement newprocurement = procurementrepo.save(procurement);
           int procurementId = newprocurement.getProducrementid ();
            model.addAttribute("procurement",procurement);

            List<Supplier> allsupplierss = (List<Supplier>)supplierrepo.findAll();
            model.addAttribute("allsuppliers",allsupplierss);
            return "redirect:/warehouse/"+procurementId;
        } else {
            List<Supplier> allsupplierss = (List<Supplier>)supplierrepo.findAll();
            model.addAttribute("allsuppliers",allsupplierss);
            return "/createprocurement";
        }

    }

    @GetMapping ("/addproductstoprocurement")
    public String insertproducttopro (HttpSession session) {
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "/addproductstoprocurement";
        } else {
            return "login";
        }
    }

    /**
     * A Post-mapping method that adds procurement items to a precurement order previously created.
     * @param model
     * @param procurementid
     * @param productno
     * @param quantity
     * @param priceadjustment
     * @param vat
     * @return
     */
    @PostMapping ("/addproductstoprocurement")
    public String insertproducttopro (Model model, @RequestParam Integer procurementid, Integer productno, Integer quantity, Float priceadjustment, Float vat, HttpSession session) {
        List<Procurement> allprocurements = (List<Procurement>)procurementrepo.findAll();
        Boolean firstinsertisok=false;

        for (int i=0;i<allprocurements.size();i++)
        {
            if (allprocurements.get(i).getProducrementid().equals(procurementid))
            {
                firstinsertisok=true;
            }
        }

        List<Product> allproducts = (List<Product>)productrepo.findAll();
        Boolean insertisok=false;

        for (int i=0;i<allproducts.size();i++)
        {
            if (allproducts.get(i).getProductno().equals(productno) && firstinsertisok)
            {
                insertisok=true;
            }
        }

        if (insertisok) {
            Procurementhasproduct addprotopro = new Procurementhasproduct(null, procurementid, productno, quantity, priceadjustment, vat, false);
            procurementproductrepo.save(addprotopro);
            model.addAttribute("addproduct",addprotopro);
            return "/addproductstoprocurement";
        } else {
            return "/addproductstoprocurement";
        }
    }



    @PostMapping ("/addproductstoprocurement/{id}")
    public String insertproducttoproid (Model model, @PathVariable Integer id, @RequestParam Integer productno, Integer quantity, Float priceadjustment, Float vat, HttpSession session) {


        List<Product> allproducts = (List<Product>)productrepo.findAll();
        Boolean insertisok=false;

        for (int i=0;i<allproducts.size();i++)
        {
            if (allproducts.get(i).getProductno().equals(productno))
            {
                insertisok=true;
            }
        }

        if (insertisok) {
            Procurementhasproduct addprotopro = new Procurementhasproduct(null, id, productno, quantity, priceadjustment, vat, false);
            procurementproductrepo.save(addprotopro);

            Procurement procurement = procurementrepo.findById(id).get();
            model.addAttribute("procurement", procurement);
            List<Procurementhasproduct> procurementhasproduct = procurementproductrepo.findAllByProcurementid(id);
            model.addAttribute("procurementhasproduct", procurementhasproduct);
            List<Product> products = new ArrayList<>();
            for (Integer i=0;i<procurementhasproduct.size();i++) {
                products.add(productrepo.findById(procurementhasproduct.get(i).getProductno()).get());
            }
            List<Product> newprodlist = products.stream().distinct().collect(Collectors.toList());
            model.addAttribute("allProducts",newprodlist);
            List<Product> assortment = (List<Product>)productrepo.findAll();
            model.addAttribute ("assortment", assortment );
            return "/HandleProcurements";
        } else {

            Procurement procurement = procurementrepo.findById(id).get();
            model.addAttribute("procurement", procurement);
            List<Procurementhasproduct> procurementhasproduct = procurementproductrepo.findAllByProcurementid(id);
            model.addAttribute("procurementhasproduct", procurementhasproduct);
            List<Product> products = new ArrayList<>();
            for (Integer i=0;i<procurementhasproduct.size();i++) {
                products.add(productrepo.findById(procurementhasproduct.get(i).getProductno()).get());
            }
            List<Product> newprodlist = products.stream().distinct().collect(Collectors.toList());
            model.addAttribute("allProducts",newprodlist);
            List<Product> assortment = (List<Product>)productrepo.findAll();
            model.addAttribute ("assortment", assortment );
            return "/HandleProcurements";
        }
    }


    @GetMapping("/warehouse/{id}")
    public String postea (Model model, @PathVariable Integer id, HttpSession session) {

        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            Procurement procurement = procurementrepo.findById(id).get();
            model.addAttribute("procurement", procurement);
            List<Procurementhasproduct> procurementhasproduct = procurementproductrepo.findAllByProcurementid(id);
            model.addAttribute("procurementhasproduct", procurementhasproduct);
            List<Product> products = new ArrayList<>();
            for (Integer i=0;i<procurementhasproduct.size();i++) {
                products.add(productrepo.findById(procurementhasproduct.get(i).getProductno()).get());
            }
            List<Product> newprodlist = products.stream().distinct().collect(Collectors.toList());
            model.addAttribute("allProducts",newprodlist);
            List<Product> assortment = (List<Product>)productrepo.findAll();
            model.addAttribute ("assortment", assortment );
            return "HandleProcurements";
        } else {
            return "login";
        }
    }

    /**
     * A Post-mapping method that adds procudts sent from suppliers to the inventory of the warehouse.
     * @param model
     * @param id
     * @return
     */
    @PostMapping("/warehouse/{id}")
    public String updateQuantity (Model model, @PathVariable Integer id, HttpSession session){
        //, @RequestParam Integer productno, Integer quantity, Float priceadjustment, Float vat,
        Procurement procurement = procurementrepo.findById(id).get();

        List<Procurementhasproduct> procurementhasproduct = procurementproductrepo.findAllByProcurementid(id);

        List<Product> products = new ArrayList<>();
        for (Integer i=0;i<procurementhasproduct.size();i++) {
            Product product = productrepo.findById(procurementhasproduct.get(i).getProductno()).get();
            Product updatedProduct = new Product(product.getProductno(),product.getName(),product.getCategory(),product.getPrice(),product.getPurchaseprice(),product.getStockquantity()+procurementhasproduct.get(i).getQuantity(),product.getSafetystock(),product.getSafetyorderquantity(),product.getSupplierid());
            productrepo.save(updatedProduct);
            products.add(productrepo.findById(procurementhasproduct.get(i).getProductno()).get());
            Procurementhasproduct updateprocurementhasproduct = new Procurementhasproduct(procurementhasproduct.get(i).getProcurementproduct(),procurementhasproduct.get(i).getProcurementid(),procurementhasproduct.get(i).getProductno(),procurementhasproduct.get(i).getQuantity(),procurementhasproduct.get(i).getPriceadjustment(),procurementhasproduct.get(i).getVat(),true);
            procurementproductrepo.save(updateprocurementhasproduct);
        }
        Procurement updatadprocurement = new Procurement(procurement.getProducrementid(),procurement.getSupplierid(),procurement.getDate(),procurement.getFreight(),true);
        procurementrepo.save(updatadprocurement);
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {

            List<Product> allProducts = (List<Product>)productrepo.findAll();
            model.addAttribute("allProducts", allProducts);
            List<Customerorder> customer = (List<Customerorder>)customerorderrepo.findAll();
            for (int i=0;i<customer.size();i++)
            {
                if (customer.get(i).getOrderhasbeensent())
                {
                    customer.remove(customer.get(i));
                    i--;
                }
            }
            model.addAttribute("customer", customer);
            List<Orderhasproduct> orderprod = (List<Orderhasproduct>)orderhasprodrepo.findAll();
            for (int i=0;i<orderprod.size();i++)
            {
                if (orderprod.get(i).getOrderhasbeensent())
                {
                    orderprod.remove(orderprod.get(i));
                    i--;
                }
            }
            model.addAttribute("orderprod", orderprod);

            List<Procurement> procurementt = (List<Procurement>)procurementrepo.findAll();
            for (int i=0;i<procurementt.size();i++)
            {
                if (procurementt.get(i).getHasbeenrecived())
                {
                    procurementt.remove(procurementt.get(i));
                    i--;
                }
            }
            model.addAttribute("procurement", procurementt);
            List<Procurementhasproduct> procurementhasproductt = (List<Procurementhasproduct>)procurementproductrepo.findAll();
            for (int i=0;i<procurementhasproductt.size();i++)
            {
                if (procurementhasproductt.get(i).getProducthasbeenrecived())
                {
                    procurementhasproductt.remove(procurementhasproductt.get(i));
                    i--;
                }
            }
            model.addAttribute("procurementhasproduct", procurementhasproductt);

            return "HandleStock";
        } else {
            return "login";
        }

    }

/*    //ANALYSIS PAGE
    @GetMapping("/analysis")
    public String analysis(HttpSession session){
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "analysis";
        } else {
            return "login";
        }
    }*/

    //TODO
    @GetMapping("/todo")
    public String todo(HttpSession session){
        String checkSession = (String)session.getAttribute("username");
        if (checkSession != null) {
            return "todo";
        } else {
            return "login";
        }
    }


//    ----------------------------------------------


    //contact
    @GetMapping("/contact")
    public String contact(HttpSession session) {
        String checkSession = (String) session.getAttribute( "username" );
        if (checkSession != null) {
            return "contact";
        } else {
            return "contact";
        }
    }
    //about
    @GetMapping("/about")
    public String about(HttpSession session) {
        String checkSession = (String) session.getAttribute( "username" );
        if (checkSession != null) {
            return "about";
        } else {
            return "about";
        }
    }
    //investors
    @GetMapping("/investors")
    public String investors(HttpSession session) {
        String checkSession = (String) session.getAttribute( "username" );
        if (checkSession != null) {
            return "investors";
        } else {
            return "investors";
        }
    }
    //investors
    @GetMapping("/work")
    public String work(HttpSession session) {
        String checkSession = (String) session.getAttribute( "username" );
        if (checkSession != null) {
            return "work";
        } else {
            return "work";
        }
    }


    @GetMapping("/analysis")
    public String analysis(Model model, HttpSession session) {
        String checkSession = (String) session.getAttribute( "username" );
        if (checkSession != null) {

            List<Product> allProducts = (List<Product>) productrepo.findAll();
            int purchasePrice = 0;
            int price = 0;
            for (int i = 0; i < allProducts.size(); i++) {
                purchasePrice += ((allProducts.get( i ).getPurchaseprice()) * (allProducts.get( i ).getStockquantity()));
                price += ((allProducts.get( i ).getPrice()) * (allProducts.get( i ).getStockquantity()));
            }

            int potentialprofit = price - purchasePrice;

            List<Customerorder> allcustorders = (List<Customerorder>) customerorderrepo.findAll();
            List<Customerorder> allsentorders = new ArrayList<>();
            List<Customerorder> allwaitingorders = new ArrayList<> ();

            for (int i = 0; i < allcustorders.size(); i++) {
                if (allcustorders.get( i ).getOrderhasbeensent()) {
                    allsentorders.add( allcustorders.get( i ) );
                }
                else {
                    allwaitingorders.add(allcustorders.get(i));
                }
            }
            List<Orderhasproduct> allorderhasprod = (List<Orderhasproduct>) orderhasprodrepo.findAll();
            List<Orderhasproduct> allproductsinorders = new ArrayList<>();
            List<Orderhasproduct> allproductsinwaitingorders = new ArrayList<> ();
            for (int i = 0; i < allsentorders.size(); i++) {
                for (int j = 0; j < allorderhasprod.size(); j++) {
                    if (allsentorders.get( i ).getOrderid() == allorderhasprod.get( j ).getOrderid()) {
                        allproductsinorders.add( allorderhasprod.get( j ) );
                    }

                }
            }

            for (int i=0;i<allwaitingorders.size();i++) {
                for (int k = 0; k < allorderhasprod.size(); k++) {
                    if (allwaitingorders.get(i).getOrderid() == allorderhasprod.get(k).getOrderid()) {
                        allproductsinwaitingorders.add(allorderhasprod.get(k));
                    }
                }
            }

            //Balansposter
            int totalsoldvalueorders = 0;
            int totalcostorderssent = 0;

            //Resultatposter
            int totalprofitorderssent = 0;

            List<Product> allproducts = (List<Product>) productrepo.findAll();
            List<Product> allproductsinorder = new ArrayList<>();
            for (int i = 0; i < allproductsinorders.size(); i++) {
                for (int j = 0; j < allproducts.size(); j++) {
                    if (allproductsinorders.get( i ).getProductno() == allproducts.get( j ).getProductno()) {
                        totalsoldvalueorders += allproductsinorders.get( i ).getQuantity() * allproducts.get( j ).getPrice();
                        totalcostorderssent += allproductsinorders.get( i ).getQuantity() * allproducts.get( j ).getPurchaseprice();
                        allproductsinorder.add( allproducts.get( j ) );
                    }
                }
            }

            //Balansposter
            int totalsoldvalueprocurement = 0;
            //int totalcostorderssent = 0;

            //Resultatposter
            //int totalprofitorderssent = 0;

            //List<Product> allproducts = (List<Product>)productrepo.findAll();
            //List<Product> allproductsinorder=new ArrayList<>();
            for (int i = 0; i < allproductsinorders.size(); i++) {
                for (int j = 0; j < allproducts.size(); j++) {
                    if (allproductsinorders.get( i ).getProductno() == allproducts.get( j ).getProductno()) {
                        totalsoldvalueorders += allproductsinorders.get( i ).getQuantity() * allproducts.get( j ).getPrice();
                        totalcostorderssent += allproductsinorders.get( i ).getQuantity() * allproducts.get( j ).getPurchaseprice();
                        //allproductsinorder.add(allproducts.get(j));
                    }
                }
            }

            int totalaccountsrecievable=0;

            for (int k = 0; k < allproductsinwaitingorders.size(); k++) {
                for (int l = 0; l < allproducts.size(); l++) {
                    if (allproductsinwaitingorders.get( k ).getProductno() == allproducts.get( l ).getProductno()) {
                        totalaccountsrecievable += allproductsinwaitingorders.get( k ).getQuantity() * allproducts.get( l ).getPrice();
                    }
                }
            }

            //Ananlys av procurements börjar här!
            List<Procurement> allprocurements = (List<Procurement>) procurementrepo.findAll();
            List<Procurement> allincomingprocurements = new ArrayList<>();
            for (int i = 0; i < allprocurements.size(); i++) {
                if (!allprocurements.get( i ).getHasbeenrecived()) {
                    allincomingprocurements.add( allprocurements.get( i ) );
                }
            }
            List<Procurementhasproduct> allprocurementhasprod = (List<Procurementhasproduct>) procurementproductrepo.findAll();
            List<Procurementhasproduct> allincomingproducts = new ArrayList<>();
            for (int i = 0; i < allincomingprocurements.size(); i++) {
                for (int j = 0; j < allprocurementhasprod.size(); j++) {
                    if (allincomingprocurements.get( i ).getProducrementid() == allprocurementhasprod.get( j ).getProcurementid()) {
                        allincomingproducts.add( allprocurementhasprod.get( j ) );
                    }
                }
            }

            //Analys av procurement-data
            int procurementcost = 0;
            List<Product> allproductsinprocurement = new ArrayList<>();
            for (int i = 0; i < allincomingproducts.size(); i++) {
                for (int j = 0; j < allproducts.size(); j++) {
                    if (allincomingproducts.get( i ).getProductno() == allproducts.get( j ).getProductno()) {
                        procurementcost += allincomingproducts.get( i ).getQuantity() * allproducts.get( j ).getPurchaseprice();
                        allproductsinprocurement.add( allproducts.get( j ) );
                    }
                }
            }

            model.addAttribute( "procurementcost", procurementcost );
            totalprofitorderssent = totalsoldvalueorders - totalcostorderssent;
            model.addAttribute ("totalaccountsrecievable", totalaccountsrecievable);
            model.addAttribute( "totalcost", totalcostorderssent );
            model.addAttribute( "totalsoldvalueorders", totalsoldvalueorders );
            model.addAttribute( "totalprofit", totalprofitorderssent );
            model.addAttribute( "numberoforders", allsentorders.size() );
            model.addAttribute( "purchasePrice", purchasePrice );
            model.addAttribute( "price", price );
            model.addAttribute( "potentialprofit", potentialprofit );

            return "analysis";
        } else {
            return "login";
        }
    }
    @GetMapping("/handleproduct/{id}")
    public String insertprod (Model model, @PathVariable int id) {
        Product product = productrepo.findById(id).get();
        model.addAttribute("product",product);
        return "HandleProduct";
    }
    @PostMapping("/handleproduct/{id}")
    public String insertprod (Model model, @PathVariable int id, @RequestParam String name, String category, Float price, Float purchaseprice, Integer stockquantity, Integer safetystock, Integer safetyorderquantity, Integer supplierid, HttpSession session) {
        List<Product> allproducts = (List<Product>)productrepo.findAll();
        List<Supplier> allsuppliers = (List<Supplier>)supplierrepo.findAll();
        Boolean productisok=false;
        for (int i=0;i<allsuppliers.size();i++)
        {
            if (allsuppliers.get(i).getSupplierid().equals(supplierid))
            {
                productisok=true;
            }
        }
        if (productisok) {
            Product prod = new Product(id,name,category,price,purchaseprice,stockquantity,safetystock,safetyorderquantity,supplierid);
            productrepo.save(prod);
            List<Product> allProducts = (List<Product>)productrepo.findAll();
            model.addAttribute("allProducts", allProducts);
            List<Customerorder> customer = (List<Customerorder>)customerorderrepo.findAll();
            for (int i=0;i<customer.size();i++)
            {
                if (customer.get(i).getOrderhasbeensent())
                {
                    customer.remove(customer.get(i));
                    i--;
                }
            }
            model.addAttribute("customer", customer);
            List<Orderhasproduct> orderprod = (List<Orderhasproduct>)orderhasprodrepo.findAll();
            for (int i=0;i<orderprod.size();i++)
            {
                if (orderprod.get(i).getOrderhasbeensent())
                {
                    orderprod.remove(orderprod.get(i));
                    i--;
                }
            }
            model.addAttribute("orderprod", orderprod);
            List<Procurement> procurement = (List<Procurement>)procurementrepo.findAll();
            for (int i=0;i<procurement.size();i++)
            {
                if (procurement.get(i).getHasbeenrecived())
                {
                    procurement.remove(procurement.get(i));
                    i--;
                }
            }
            model.addAttribute("procurement", procurement);
            List<Procurementhasproduct> procurementhasproduct = (List<Procurementhasproduct>)procurementproductrepo.findAll();
            for (int i=0;i<procurementhasproduct.size();i++)
            {
                if (procurementhasproduct.get(i).getProducthasbeenrecived())
                {
                    procurementhasproduct.remove(procurementhasproduct.get(i));
                    i--;
                }
            }
            model.addAttribute("procurementhasproduct", procurementhasproduct);
            return "HandleStock";
        } else {
            return "HandleProduct";
        }
    }
}
