package com.example.MatPro;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Procurementhasproduct {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer procurementproduct;
    int procurementid;
    int productno;
    int quantity;
    float priceadjustment;
    float vat;
    Boolean producthasbeenrecived;

    public Procurementhasproduct() {
    }

    public Procurementhasproduct(Integer procurementproduct, int procurementid, int productno, int quantity, float priceadjustment, float vat, Boolean producthasbeenrecived) {
        this.procurementproduct = procurementproduct;
        this.procurementid = procurementid;
        this.productno = productno;
        this.quantity = quantity;
        this.priceadjustment = priceadjustment;
        this.vat = vat;
        this.producthasbeenrecived = producthasbeenrecived;
    }

    public Boolean getProducthasbeenrecived() {
        return producthasbeenrecived;
    }

    public void setProducthasbeenrecived(Boolean producthasbeenrecived) {
        this.producthasbeenrecived = producthasbeenrecived;
    }

    public Integer getProcurementproduct() {
        return procurementproduct;
    }

    public void setProcurementproduct(Integer procurementproduct) {
        this.procurementproduct = procurementproduct;
    }

    public int getProcurementid() {
        return procurementid;
    }

    public void setProcurementid(int procurementid) {
        this.procurementid = procurementid;
    }

    public int getProductno() {
        return productno;
    }

    public void setProductno(int productno) {
        this.productno = productno;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getPriceadjustment() {
        return priceadjustment;
    }

    public void setPriceadjustment(float priceadjustment) {
        this.priceadjustment = priceadjustment;
    }

    public float getVat() {
        return vat;
    }

    public void setVat(float vat) {
        this.vat = vat;
    }
}
