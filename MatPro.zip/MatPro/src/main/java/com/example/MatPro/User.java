package com.example.MatPro;

public class User {

    private String user;

    public User() {
    }

    public User(String user) {
        this.user = user;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
