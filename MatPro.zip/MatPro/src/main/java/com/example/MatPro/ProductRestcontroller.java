package com.example.MatPro;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;
import java.sql.*;

@RestController
public class ProductRestcontroller {





//    String connstr = "jdbc:sqlserver://localhost;databasename=MatProject;user=dbadmin;password=123123";
//
//        @GetMapping("/dbtest")
//        public String testDb() throws SQLException {
//            try (Connection conn = DriverManager.getConnection(connstr)){
//            Statement stmt = conn.createStatement();
//                 ResultSet rs = stmt.executeQuery("SELECT 1+1");
//                rs.next();
//                int two = rs.getInt(1);
//                return "Database connectivity is " + (two == 2 ? "working!" : "NOT working!");
//            }
//        }
   }

