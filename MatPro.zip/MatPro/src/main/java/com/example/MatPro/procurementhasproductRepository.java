package com.example.MatPro;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface procurementhasproductRepository extends CrudRepository<Procurementhasproduct, Integer> {
    List<Procurementhasproduct> findAllByProductno(int productno);
    List<Procurementhasproduct> findAllByProcurementid(int procurementid);
    //List<Procurementhasproduct> findAllPByProductid (int productid);
}
