package com.example.MatPro;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDate;
import java.util.Date;

@Entity
public class Procurement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Integer producrementid;
    Integer supplierid;
    LocalDate date;
    float freight;
    Boolean hasbeenrecived;

    public Procurement() {
    }

    public Procurement(Integer producrementid, Integer supplierid, LocalDate date, float freight, Boolean hasbeenrecived) {
        this.producrementid = producrementid;
        this.supplierid = supplierid;
        this.date = date;
        this.freight = freight;
        this.hasbeenrecived = hasbeenrecived;
    }

    public Boolean getHasbeenrecived() {
        return hasbeenrecived;
    }

    public void setHasbeenrecived(Boolean hasbeenrecived) {
        this.hasbeenrecived = hasbeenrecived;
    }

    public Integer getProducrementid() {
        return producrementid;
    }

    public void setProducrementid(Integer producrementid) {
        this.producrementid = producrementid;
    }

    public Integer getSupplierid() {
        return supplierid;
    }

    public void setSupplierid(Integer supplierid) {
        this.supplierid = supplierid;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public float getFreight() {
        return freight;
    }

    public void setFreight(float freight) {
        this.freight = freight;
    }
}
